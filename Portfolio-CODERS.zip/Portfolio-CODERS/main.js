window.addEventListener('load', () => {
    const intro = document.getElementById('intro');
    intro.style.opacity = 1;
});